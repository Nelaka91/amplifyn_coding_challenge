<script setup lang="ts">
import PathCalculator from './components/PathCalculatorComponent.vue'
</script>

<template>
  <main>
    <PathCalculator />
  </main>
</template>

<style scoped></style>
